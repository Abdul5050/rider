package com.taxi.rider

import io.flutter.embedding.android.FlutterFragmentActivity
import io.flutter.embedding.engine.FlutterEngine

import android.content.Intent
import android.content.pm.PackageInfo
import android.os.Build
import android.text.TextUtils
import io.flutter.embedding.android.FlutterActivity
import io.flutter.plugin.common.MethodChannel
import java.io.BufferedReader
import java.io.IOException
import java.io.InputStreamReader
import java.util.*

class MainActivity: FlutterFragmentActivity() {
    private val CHANNEL = "notiOpen"
    private val CHANNEL2 = "getDeviceInfo"

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        MethodChannel(
                flutterEngine.dartExecutor.binaryMessenger,
                CHANNEL
        ).setMethodCallHandler { call, result ->
            if (call.method == "startNotiOpen") {
                notifiOpen()
            } else {
                result.notImplemented()
            }
        }

        MethodChannel(
                flutterEngine.dartExecutor.binaryMessenger,
                CHANNEL2
        ).setMethodCallHandler { call, result ->
            if (call.method == "getAndroidInfo") {
                val deviceInfo = getDeviceInfo()
                if (deviceInfo.isNotEmpty()) {
                    result.success(deviceInfo)
                } else {
                    result.error("UNAVAILABLE", "Not Recived Device Info", null)
                }
            } else {
                result.notImplemented()
            }
        }
    }

    private fun getDeviceInfo(): Map<String, Any> {
        var deviceInfo: Map<String, Any> = mapOf()
        try {
            val packageInfo: PackageInfo = applicationContext.getPackageManager()
                    .getPackageInfo(applicationContext.getPackageName(), 0)
            deviceInfo = mapOf(
                    "MANUFACTURER" to Build.MANUFACTURER,
                    "BRAND" to Build.BRAND,
                    "MODEL" to Build.MODEL,
                    "BOARD" to Build.BOARD,
                    "HARDWARE" to Build.HARDWARE,
                    "BUILD_CODE" to Build.VERSION.SDK_INT,
                    "BUILD_CODE" to BuildConfig.VERSION_CODE,
                    "DEVICE" to Build.DEVICE,
                    "ID" to Build.ID,
                    "VERSION_NAME" to Build.VERSION.RELEASE,
                    "TYPE" to Build.TYPE,
                    "APP_VERSION" to packageInfo.versionName,
                    "APP_BUILD_NUMBER" to packageInfo.longVersionCode,
                    "IS_OS_MIUI" to !TextUtils.isEmpty(getSystemProperty("ro.miui.ui.version.name"))
            )
            return deviceInfo
        } catch (e: Exception) {
        }
        return deviceInfo
    }

    private fun notifiOpen() {
        try {
            val intent = Intent("miui.intent.action.APP_PERM_EDITOR")
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            val manufacturer = Build.MANUFACTURER
            if ("xiaomi".equals(manufacturer, ignoreCase = true)) {
                intent.setClassName(
                        "com.miui.securitycenter",
                        "com.miui.permcenter.permissions.PermissionsEditorActivity"
                );
                intent.putExtra("extra_pkgname", "com.yourpackagename")
                startActivity(intent);
            }
        } catch (ignore: java.lang.Exception) {
        } catch (e: Exception) {
        }
        try {
            val intent = Intent("miui.intent.action.APP_PERM_EDITOR")
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            val manufacturer = Build.MANUFACTURER
            if ("xiaomi".equals(manufacturer, ignoreCase = true)) {
                intent.setClassName(
                        "com.miui.securitycenter",
                        "com.miui.permcenter.permissions.AppPermissionsEditorActivity"
                )
                intent.putExtra("extra_pkgname", "com.yourpackagename")
                startActivity(intent)
            }
        } catch (ignore: java.lang.Exception) {
        } catch (e: Exception) {
        }
    }

    fun getSystemProperty(propName: String): String? {
        val line: String
        var input: BufferedReader? = null
        try {
            val p = Runtime.getRuntime().exec("getprop $propName")
            input = BufferedReader(InputStreamReader(p.inputStream), 1024)
            line = input.readLine()
            input.close()
        } catch (ex: IOException) {
            return null
        } finally {
            if (input != null) {
                try {
                    input.close()
                } catch (e: IOException) {
                    e.printStackTrace()
                }
            }
        }
        return line
    }
}